import { motion } from 'motion/react';
import { Phone, Mail, MapPin, Award, CheckCircle2, Menu, X, ArrowRight, Star, Quote, Volume2, VolumeX, MessageCircle, Send, Loader2 } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";

// --- Components ---

const Logo = ({ className = "" }: { className?: string }) => (
  <div className={`flex items-center font-sans font-bold leading-none select-none ${className}`}>
    <div className="flex items-baseline gap-0.5">
      <span className="text-[#D9C5A3] text-4xl tracking-tighter">Trim</span>
      <div className="relative">
        {/* The dot over 'i' in Trim is specifically orange in the logo */}
        <div className="absolute -top-[1.1em] left-[0.15em] w-3 h-3 bg-brand-orange rounded-full"></div>
      </div>
    </div>
    <div className="bg-brand-orange px-2 py-1 ml-1 transform -skew-x-2">
      <span className="text-white text-4xl tracking-tighter lowercase">team</span>
    </div>
  </div>
);

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 bg-brand-cream/90 backdrop-blur-md border-b border-brand-charcoal">
      <div className="max-w-7xl mx-auto px-6 h-24 flex items-center justify-between">
        <div className="flex flex-col">
          <Logo className="scale-75 md:scale-90 -ml-4" />
          <span className="text-[10px] uppercase tracking-[0.2em] font-bold mt-1 opacity-70 ml-2">Design & Build — Est. 2004</span>
        </div>
        
        <div className="hidden md:flex items-center gap-12">
          <a href="#refresh" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Home Refresh</a>
          <a href="#gallery" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Gallery</a>
          <a href="#stories" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Stories</a>
          <a href="#showcase" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Showcase</a>
          <a href="#awards" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Awards</a>
          <a href="#testimonials" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Voices</a>
          <a href="#process" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Process</a>
          <a href="#services" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Services</a>
          <a href="#crew" className="text-[10px] uppercase tracking-widest font-bold hover:text-brand-orange transition-colors">Crew</a>
          <a href="#contact" className="bg-brand-charcoal text-white px-8 py-4 text-[10px] uppercase tracking-widest font-bold hover:bg-brand-orange transition-all">Get in Touch</a>
        </div>

        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="md:hidden bg-brand-cream border-b border-brand-charcoal p-10 flex flex-col gap-6"
        >
          <a href="#refresh" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Home Refresh</a>
          <a href="#gallery" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Gallery</a>
          <a href="#stories" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Stories</a>
          <a href="#showcase" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Showcase</a>
          <a href="#awards" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Awards</a>
          <a href="#testimonials" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Voices</a>
          <a href="#process" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Process</a>
          <a href="#services" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Services</a>
          <a href="#crew" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic underline decoration-brand-orange">Crew</a>
          <a href="#contact" onClick={() => setIsOpen(false)} className="text-3xl font-serif font-bold italic text-brand-orange">Contact</a>
        </motion.div>
      )}
    </nav>
  );
};

const BrandVoice = () => {
  const [isMuted, setIsMuted] = useState(true);

  return (
    <section className="py-24 px-6 bg-brand-cream border-b border-brand-charcoal overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-12 gap-16 items-center">
          <div className="lg:col-span-6">
            <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-8">The Authority / Sebastian Puc</span>
            <h2 className="text-6xl md:text-8xl italic font-serif leading-[0.9] mb-12">
              "We build for legacy, not for speed."
            </h2>
            <div className="space-y-8">
              <p className="text-2xl font-light text-brand-gray leading-relaxed">
                I’ve spent two decades watching contractors cut corners in New Jersey homes. My voice is the only one you’ll hear from day one until the final stroke of paint. No sales teams. No fluff. Just rzemiosło.
              </p>
              <div className="flex items-center gap-6 p-8 bg-brand-charcoal text-white rounded-lg">
                <div className="w-16 h-16 rounded-full bg-brand-orange flex items-center justify-center flex-shrink-0">
                  <Quote size={24} className="text-white" />
                </div>
                <div>
                  <p className="text-lg font-serif italic">"If you want to save money, do not call. If you want it done right once, we are here."</p>
                  <p className="text-[10px] uppercase tracking-widest font-bold text-brand-orange mt-2">— Sebastian Puc</p>
                </div>
              </div>
            </div>
          </div>
          <div className="lg:col-span-6">
            <div className="relative aspect-video rounded-2xl overflow-hidden shadow-2xl group cursor-pointer border-4 border-brand-charcoal" onClick={() => setIsMuted(!isMuted)}>
              <video 
                autoPlay 
                muted={isMuted}
                loop 
                playsInline 
                key={isMuted ? "muted-brand" : "unmuted-brand"}
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
              >
                <source src="https://storage.googleapis.com/antigravity-artifacts/input_file_0.mp4" type="video/mp4" />
                Your browser does not support the video tag.
              </video>
              <div className="absolute top-4 right-4 z-20 bg-brand-orange p-2 rounded-full">
                {isMuted ? <VolumeX size={16} className="text-white" /> : <Volume2 size={16} className="text-white" />}
              </div>
              <div className="absolute inset-0 bg-brand-charcoal/20 opacity-100 group-hover:opacity-0 transition-opacity flex items-center justify-center">
                <div className="text-center">
                  <div className="w-20 h-20 bg-brand-orange rounded-full flex items-center justify-center mb-4 mx-auto animate-pulse">
                    <Volume2 size={32} className="text-white" />
                  </div>
                  <p className="text-white text-xs uppercase tracking-widest font-bold">Unmute to hear the Brand Voice</p>
                </div>
              </div>
            </div>
            <p className="text-[10px] uppercase tracking-[0.3em] font-bold text-brand-charcoal mt-6 text-center opacity-40">Authenticity Guarantee — Direct Message from Sebastian</p>
          </div>
        </div>
      </div>
    </section>
  );
};

const Hero = () => (
  <section className="pt-48 pb-24 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-12 gap-16 items-start">
        <div className="lg:col-span-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-7xl md:text-9xl lg:text-[11rem] leading-[0.8] mb-12 italic font-serif">
              Design <br />& Build
            </h1>
            <p className="text-2xl md:text-3xl font-medium tracking-tight text-brand-charcoal max-w-2xl leading-snug">
              We don’t take every project. We don’t rush. We don’t try to be the cheapest. 
              We’ve spent 22 years perfecting NJ homes.
            </p>
          </motion.div>
        </div>
        <div className="lg:col-span-4 flex flex-col items-start lg:items-end gap-12 lg:pt-12">
          <div className="flex flex-col items-start lg:items-end border-b-2 border-brand-charcoal pb-4 w-full">
            <span className="text-6xl font-bold text-brand-charcoal">12</span>
            <span className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-60">Years Best of Houzz</span>
          </div>
          <a href="#contact" className="group flex items-center gap-6 bg-brand-orange text-white px-10 py-10 rounded-full hover:scale-105 transition-transform text-center">
            <span className="text-sm uppercase tracking-[0.3em] font-bold">Talk to Sebastian</span>
            <ArrowRight className="group-hover:translate-x-2 transition-transform" />
          </a>
        </div>
      </div>
    </div>
  </section>
);

const HomeRefresh = () => (
  <section id="refresh" className="py-32 bg-brand-charcoal text-brand-cream overflow-hidden">
    <div className="max-w-7xl mx-auto px-6">
      <div className="grid md:grid-cols-12 gap-16 items-start mb-24">
        <div className="md:col-span-7">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">The Signature Product</span>
          <h2 className="text-7xl md:text-9xl lg:text-[10rem] italic leading-[0.85] mb-10">Home <br />Refresh</h2>
          <p className="text-2xl md:text-3xl font-light leading-snug max-w-xl">
            Updating what’s dated. Keeping what’s beautiful. One team, one vision, one cohesive outcome.
          </p>
        </div>
        <div className="md:col-span-5 pt-12 md:pt-32">
          <div className="border border-white/20 p-10 bg-white/5 backdrop-blur-sm">
            <p className="text-xl italic font-serif leading-relaxed opacity-90">
              "Klient zatrudniający 5 firm do jednego remontu dostaje 5 perspektyw i 0 odpowiedzialności za końcowy efekt. Home Refresh rozwiązuje to strukturalnie."
            </p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-20">
        <div className="aspect-[4/5] border border-white/10 relative group">
          <img 
            src="https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1000" 
            alt="Home Refresh Example" 
            className="absolute inset-0 w-full h-full object-cover grayscale brightness-40 group-hover:grayscale-0 group-hover:brightness-100 transition-all duration-700"
          />
        </div>

        <div className="flex flex-col justify-between py-6">
          <div className="space-y-12">
            <div className="flex flex-col gap-4">
              <span className="text-[10px] uppercase tracking-[0.3em] font-bold opacity-40">The Advantage</span>
              <h3 className="text-4xl uppercase">Concierge Focus</h3>
              <p className="text-brand-gray text-xl font-light">We coordinate every element—kitchens, bathrooms, flooring, and lighting—into one objective modernization of your NJ home.</p>
            </div>
            
            <div className="grid grid-cols-2 gap-12 border-t border-b border-white/10 py-10">
              <div className="flex flex-col">
                <span className="text-4xl font-bold uppercase">22</span>
                <span className="text-[10px] uppercase tracking-widest font-bold opacity-40">Years in NJ</span>
              </div>
              <div className="flex flex-col">
                <span className="text-4xl font-bold uppercase italic font-serif">10+</span>
                <span className="text-[10px] uppercase tracking-widest font-bold opacity-40">Tenure</span>
              </div>
            </div>
          </div>

          <div className="bg-brand-orange p-10 mt-12 flex flex-col justify-between h-auto min-h-[240px]">
            <h3 className="text-3xl font-bold uppercase leading-none text-white">If you want to save money, do not call.</h3>
            <p className="text-sm italic text-white/80 mt-6">Quality takes time. Rushing costs more than patience. We don’t try to be the cheapest.</p>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const CoreServices = () => (
  <section id="services" className="py-24 px-6 border-b border-brand-charcoal/10">
    <div className="max-w-7xl mx-auto">
      <div className="mb-20">
        <h2 className="text-4xl md:text-6xl mb-6">Core Craft</h2>
        <p className="text-xl text-brand-gray font-light max-w-2xl">
          Everything starts with our own crew. 10+ year average tenure. Polish rzemiosło tradition meets modern NJ design.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-x-12 gap-y-16">
        {[
          {
            title: "Social Spaces",
            description: "Media & TV Wall Units, Custom Bar Units, Fireplace Surrounds.",
            img: "https://images.unsplash.com/photo-1594026112284-02bb6f3352fe?auto=format&fit=crop&q=80&w=600"
          },
          {
            title: "Libraries & Offices",
            description: "Custom Home Libraries, Specialized Office Suites, Coffered Ceilings.",
            img: "https://images.unsplash.com/photo-1507842217343-583bb7270b66?auto=format&fit=crop&q=80&w=600"
          },
          {
            title: "Smart Storage",
            description: "Mudrooms, Custom Walk-in Closets, Functional Built-ins.",
            img: "https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&q=80&w=600"
          }
        ].map((service, i) => (
          <motion.div 
            key={i}
            whileHover={{ y: -10 }}
            className="group"
          >
            <div className="aspect-[3/4] bg-white mb-6 overflow-hidden grayscale group-hover:grayscale-0 transition-all duration-500">
              <img src={service.img} alt={service.title} className="w-full h-full object-cover" />
            </div>
            <h3 className="text-2xl mb-2">{service.title}</h3>
            <p className="text-brand-gray font-light leading-relaxed">{service.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Gallery = () => (
  <section id="gallery" className="py-32 px-6 bg-brand-cream border-t border-brand-charcoal/10">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-12 gap-16 mb-24">
        <div className="lg:col-span-8">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Gallery / Custom Shelving</span>
          <h2 className="text-7xl md:text-9xl italic leading-[0.85] mb-10">Bookcases <br />& Shelves</h2>
        </div>
        <div className="lg:col-span-4 lg:pt-20">
          <p className="text-xl font-light text-brand-gray leading-relaxed mb-8">
            Interested in customizable and practical storage that integrates into your home? We design, build, install, and paint original built-ins and bookshelves that fit—even in the most complicated areas.
          </p>
          <div className="p-6 bg-white border-l-2 border-brand-orange italic text-brand-gray">
            "We hide ports and cables while preserving access and full functionality. Organization meets architectural addition."
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[
          "custom-fireplace-nj-1.jpg",
          "custom-fireplace-nj-2.jpg",
          "custom-fireplace-nj-3.jpg",
          "custom-fireplace-nj-4.jpg",
          "custom-fireplace-nj-5.jpg",
          "custom-fireplace-nj-6.jpg",
          "custom-fireplace-nj-7.jpg",
          "custom-fireplace-nj-8.jpg",
          "custom-fireplace-nj-9.jpg",
          "custom-fireplace-nj-10.jpg"
        ].map((img, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className={`overflow-hidden grayscale hover:grayscale-0 transition-all duration-700 bg-white border border-brand-charcoal/5 ${
              i === 2 || i === 5 ? "md:row-span-2" : ""
            }`}
          >
            <img 
              src={img} 
              alt={`Custom Bookcase ${i + 1}`} 
              className="w-full h-full object-cover aspect-square hover:scale-105 transition-transform duration-700" 
              referrerPolicy="no-referrer"
            />
          </motion.div>
        ))}
      </div>

      <div className="mt-32 border-t border-brand-charcoal/10 pt-24">
        <div className="mb-16">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Expertise 360° / Interactive</span>
          <h3 className="text-5xl italic mb-6 leading-tight">Digital Catalogs</h3>
          <p className="text-xl font-light text-brand-gray max-w-2xl">
            Experience our architectural woodwork in 360°. Flip through our specialized catalogs to see the details of our signature structures.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Catalog 1 - Wall Units (Assuming this is the first one commonly used, or placeholder) */}
          <div className="space-y-6">
            <div className="flipbook-container shadow-2xl border border-brand-charcoal/5">
              <iframe 
                className="flipbook-iframe"
                src="https://online.fliphtml5.com/kvxoq/uzsk/" 
                title="Wall Units with Trim Team" 
                seamless={true}
                scrolling="no" 
                frameBorder="0" 
                allowFullScreen={true}
              ></iframe>
            </div>
            <div>
              <h4 className="text-2xl italic">Wall Units & Media Centers</h4>
              <p className="text-sm text-brand-gray font-light mt-2 uppercase tracking-widest opacity-60 italic">Interactive Catalog — Vol. 01</p>
            </div>
          </div>

          {/* Catalog 2 - Coffered Ceilings (Provided by user) */}
          <div className="space-y-6">
            <div style={{ position: 'relative', paddingTop: 0, width: '100%', maxWidth: '700px', height: '400px' }} className="shadow-2xl border border-brand-charcoal/5 mx-auto">
              <iframe 
                style={{ position: 'absolute', border: 'none', width: '100%', height: '100%', left: 0, top: 0 }}
                src="https://online.fliphtml5.com/kvxoq/COFFER_20_IV-pw0Y/" 
                title="Coffered Ceiling with Trim Team" 
                seamless={true}
                scrolling="no" 
                frameBorder="0" 
                allowFullScreen={true}
              ></iframe>
            </div>
            <div className="text-center md:text-left">
              <h4 className="text-2xl italic">Coffered Ceilings & Overhead Detail</h4>
              <p className="text-sm text-brand-gray font-light mt-2 uppercase tracking-widest opacity-60 italic">Interactive Catalog — Vol. 02</p>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-16 text-center">
        <p className="text-brand-gray font-light mb-8">Browse hundreds of projects to find inspiration for your space.</p>
        <a href="#contact" className="inline-block border-b-2 border-brand-orange pb-2 text-brand-charcoal font-bold uppercase tracking-widest hover:text-brand-orange transition-colors">Start Your Project</a>
      </div>
    </div>
  </section>
);

const Philosophy = () => (
  <section id="philosophy" className="py-32 px-6 bg-brand-cream">
    <div className="max-w-4xl mx-auto text-center">
      <span className="text-brand-orange uppercase text-xs tracking-[0.4em] font-bold block mb-8">Our Credo</span>
      <h2 className="text-5xl md:text-7xl leading-tight mb-12 italic font-serif">
        "If you want to save money, do not call."
      </h2>
      <div className="grid md:grid-cols-2 gap-12 text-left mt-20">
        <div className="space-y-6">
          <p className="text-xl font-medium">Good work is fast work.</p>
          <p className="text-brand-gray leading-relaxed">
            We don't rush. Thinking and planning comes first. Mistakes from haste cost more than the time saved. 
            We spend the first 30 minutes of every day building trust through extreme protection of your home.
          </p>
        </div>
        <div className="space-y-6">
          <p className="text-xl font-medium">Trusted Elder Authority.</p>
          <p className="text-brand-gray leading-relaxed">
            Sebastian doesn't sell. He tells it like it is. Honest boundaries, transparent pricing, and 22 years 
            of knowing these NJ layouts by heart. We've worked in your neighbor's home.
          </p>
        </div>
      </div>
    </div>
  </section>
);

const ClientStories = () => (
  <section id="stories" className="py-32 bg-white">
    <div className="max-w-7xl mx-auto px-6">
      <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
        <div className="max-w-2xl">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Big 5 Framework: Evidence</span>
          <h2 className="text-7xl md:text-9xl leading-[0.8] italic mb-8">Client <br />Stories</h2>
          <p className="text-2xl font-light text-brand-gray">Długie narracyjne case studies, nie one-line testimoniale. Realne problemy, spójne rozwiązania.</p>
        </div>
        <div className="flex gap-4">
          <div className="border border-brand-charcoal p-4 group cursor-pointer hover:bg-brand-charcoal hover:text-white transition-all">
            <span className="text-[10px] font-bold uppercase tracking-widest">Scroll to Explore</span>
          </div>
        </div>
      </div>

      <div className="space-y-40">
        {[
          {
            tag: "Home Refresh™ Model",
            title: "The Monmouth County Estate",
            problem: "A 12,000 sq ft home built in 2002 by a large developer. The 'bones' were excellent, but the interior was dated—yellowed oak, heavy cherry wood everywhere, and a fragmented layout that felt small despite the square footage. The client faced 'decision paralysis' from hiring multiple disconnected specialists.",
            solution: "We applied the full Home Refresh™ concierge model. Instead of tearing down walls, we unified the space through architectural woodwork. We replaced the cherry library with a specialized navy-stain study, modernized the grand staircase with structural railing updates, and integrated a lighting plan that highlighted the new, refined textures.",
            outcome: "The project was completed in 21 days with zero subcontractors outside our vetted circle. The valuation increased significantly, but more importantly, the client avoided the chaos of a gut-renovation. 'One team. One vision. One cohesive outcome.'",
            img: "https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200"
          },
          {
            tag: "Woodwork Heritage",
            title: "The NBA Professional Residence",
            problem: "A client required privacy and a level of woodworking precision found in European ateliers. The primary social space lacked a visual anchor, and standard market solutions felt 'commodity' rather than 'custom.'",
            solution: "Sebastian and Miro designed a triple-height Fireplace Surround integrated with hidden media cabinetry. Using Eastern European apprenticeship techniques, we created perfect mitered corners and a functional stain-grade finish that matched the client's rare art collection.",
            outcome: "A massive visual anchor that defines the property. The project proved our 'heritage foundation'—that quality woodwork is not just about building cabinets, but about architectural honesty and craftsmanship that survives trends.",
            img: "https://images.unsplash.com/photo-1600607687940-47ea0e923155?auto=format&fit=crop&q=80&w=1200"
          },
          {
            tag: "20-Year Modernization",
            title: "The 1995 Boom-Era Refresh",
            problem: "A classic Toll Brothers-style home in Somerset County. It suffered from the typical 90s boom-era issues: generic molding that was falling apart, cheap painting finishes, and a dark entryway that didn't reflect the family's lifestyle. The budget was $75k with a strict 2-week window.",
            solution: "We focused on 'High-Impact Architectural Enhancements.' We stripped the generic trim and replaced it with custom-designed wall paneling and wainscoting. Jerry coordinated a complete interior painting refresh using a curated organic palette.",
            outcome: "The home felt 'custom-built' rather than 'developer-built.' Completed exactly on day 12. We spent the first 30 minutes of every day protecting the floors and furniture—the client noted that the house was cleaner after we left than before we started.",
            img: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&q=80&w=1200"
          }
        ].map((story, i) => (
          <div key={i} className="grid lg:grid-cols-12 gap-16 items-start">
            <div className="lg:col-span-7 space-y-12">
              <div className="flex items-center gap-6">
                <span className="text-3xl font-serif font-bold italic opacity-20">0{i + 1}</span>
                <span className="text-[10px] uppercase tracking-[0.3em] font-bold text-brand-orange">{story.tag}</span>
              </div>
              <h3 className="text-5xl md:text-7xl leading-none">{story.title}</h3>
              
              <div className="grid md:grid-cols-2 gap-12 pt-12 border-t border-brand-line">
                <div className="space-y-4">
                  <span className="text-[10px] uppercase tracking-widest font-bold opacity-50">The Problem</span>
                  <p className="text-lg leading-relaxed font-light">{story.problem}</p>
                </div>
                <div className="space-y-4">
                  <span className="text-[10px] uppercase tracking-widest font-bold opacity-50">The Solution</span>
                  <p className="text-lg leading-relaxed font-light font-medium">{story.solution}</p>
                </div>
              </div>
              <div className="bg-brand-cream p-10 mt-8 border-l-4 border-brand-orange">
                <span className="text-[10px] uppercase tracking-widest font-bold opacity-50 block mb-4">The Outcome</span>
                <p className="text-2xl font-serif italic text-brand-charcoal">{story.outcome}</p>
              </div>
            </div>
            <div className="lg:col-span-5 sticky top-32">
              <div className="aspect-[3/4] overflow-hidden grayscale hover:grayscale-0 transition-all duration-1000 border border-brand-charcoal/10">
                <img src={story.img} alt={story.title} className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  </section>
);
const Testimonials = () => (
  <section id="testimonials" className="py-32 px-6 bg-brand-cream border-t border-brand-charcoal/10">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-12 gap-16 mb-24">
        <div className="lg:col-span-8">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Social Proof</span>
          <h2 className="text-7xl md:text-9xl italic leading-[0.85] mb-10">Client <br />Voices</h2>
        </div>
        <div className="lg:col-span-4 lg:pt-20">
          <p className="text-xl font-light text-brand-gray leading-relaxed italic border-l border-brand-orange pl-8">
            "Your home is your legacy. We treat it as such. But don’t just take our word for it—listen to the homeowners who lived through our process."
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-12">
        {[
          {
            name: "Alex Kahan",
            quote: "These guys were great! Marek and his team really took the time to make my house look beautiful. They spent months changing out doors and hardware and installing/painting trim. Despite the high cost, the price quoted upfront was the price charged in the end and I more than felt it was money well spent.",
            highlight: "Money well spent."
          },
          {
            name: "Kristin Herring",
            quote: "Marek and team are fantastic and I would recommend them to anyone without question. They additionally worked seamless magic on what seemed like an impossible mismatched flooring situation. They are perfectionists, clean, efficient and friendly.",
            highlight: "Incredibly accommodating."
          },
          {
            name: "Harry Kopp",
            quote: "Professional, reliable and true tradesmen. They brought that unique look to our home with crown moldings, trim, coffered ceilings and custom wall units. I would highly recommend this team to anyone looking to bring quality work into their home.",
            highlight: "True tradesmen."
          }
        ].map((testimonial, i) => (
          <div key={i} className="flex flex-col bg-white p-10 border border-brand-charcoal/5 relative group hover:shadow-xl transition-all duration-500">
            <div className="flex gap-1 mb-8 text-brand-orange">
              {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
            </div>
            <p className="text-2xl font-serif italic mb-8 leading-tight">"{testimonial.highlight}"</p>
            <p className="text-brand-gray font-light leading-relaxed mb-8 text-sm italic">
              {testimonial.quote}
            </p>
            <div className="mt-auto pt-8 border-t border-brand-charcoal/10">
              <p className="text-xs uppercase font-bold tracking-widest">{testimonial.name}</p>
              <p className="text-[10px] text-brand-orange uppercase font-bold tracking-widest mt-1">Verified Homeowner</p>
            </div>
            <Quote className="absolute top-8 right-8 opacity-5 text-brand-charcoal" size={60} />
          </div>
        ))}
      </div>

      <div className="mt-24 text-center">
        <div className="inline-flex items-center gap-4 px-8 py-4 bg-brand-charcoal text-white">
          <Award size={20} className="text-brand-orange" />
          <span className="text-xs uppercase font-bold tracking-[0.2em]">12 Consecutive Years of 5-Star Excellence</span>
        </div>
      </div>
    </div>
  </section>
);

const MeetTheCrew = () => (
  <section id="crew" className="py-32 bg-brand-cream border-t border-brand-charcoal">
    <div className="max-w-7xl mx-auto px-6">
      <div className="grid lg:grid-cols-12 gap-16 mb-24">
        <div className="lg:col-span-8">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">The Human Element</span>
          <h2 className="text-7xl md:text-9xl italic leading-[0.85] mb-10">Meet the <br />Crew</h2>
        </div>
        <div className="lg:col-span-4 lg:pt-20">
          <p className="text-xl font-light text-brand-gray leading-relaxed">
            Our average tenure is 10+ years. We don't use a rotating army of subcontractors. The people you meet are the people who work in your home.
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-20">
        {[
          { 
            name: "Sebastian", 
            role: "Founder / Lead Designer", 
            bio: "22 years of heritage. The creative mind behind our strategy and signature Design & Build philosophy. Eastern European apprenticeship tradition." 
          },
          { 
            name: "Fabian", 
            role: "Project Coordinator", 
            bio: "First point of contact for project inquiries. Manages designer partnerships and ensures every residential project meets our established standard." 
          },
          { 
            name: "Slawek", 
            role: "Project Manager", 
            bio: "Client coordinator and strategic partner. Slawek manages our core projects, ensuring communication and timelines are respected from day one." 
          },
          { 
            name: "Miro", 
            role: "Master Installation", 
            bio: "Our master carpenter with over 10 years at Trim Team. Miro coordinates high-precision installations and ensures mitered perfection." 
          },
          { 
            name: "Jerry", 
            role: "Color Specialist", 
            bio: "Our painting and finishing coordinator. Jerry ensures the final layer—whether stain-grade or paint-grade—is flawless and durable." 
          }
        ].map((person, i) => (
          <div key={i} className="flex flex-col border-t-2 border-brand-charcoal pt-8 relative overflow-hidden group">
            <span className="text-[10px] font-bold text-brand-orange mb-4 tracking-widest uppercase">0{i + 1}</span>
            <h4 className="text-4xl font-serif italic mb-2 group-hover:translate-x-2 transition-transform duration-300">{person.name}</h4>
            <p className="text-xs font-bold uppercase tracking-widest mb-6 opacity-60 italic">{person.role}</p>
            <p className="text-brand-gray leading-relaxed font-light">{person.bio}</p>
          </div>
        ))}
        {/* Placeholder for the 'Sebastian Quote' vibe */}
        <div className="flex flex-col border-t-2 border-brand-charcoal pt-8 bg-brand-orange p-8 text-white">
          <p className="text-2xl font-serif italic mb-4 leading-tight">“Good work is fast work.”</p>
          <p className="text-[10px] uppercase font-bold tracking-widest opacity-80">Sebastian's Golden Rule</p>
        </div>
      </div>

      <div className="mt-32 pt-16 border-t border-brand-line flex flex-col md:flex-row justify-between items-center gap-12">
        <div className="flex items-center gap-6">
          <Award className="text-brand-orange" size={40} />
          <div>
            <p className="text-xs uppercase tracking-widest font-bold opacity-40">Heritage</p>
            <p className="text-xl font-serif italic">Polish Craftsmanship Tradition since 2004</p>
          </div>
        </div>
        <div className="flex items-center gap-6">
          <CheckCircle2 className="text-brand-orange" size={40} />
          <div>
            <p className="text-xs uppercase tracking-widest font-bold opacity-40">Continuity</p>
            <p className="text-xl font-serif italic">Same team from measure to finish</p>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const ProjectShowcase = () => (
  <section id="showcase" className="py-32 px-6 bg-brand-cream border-t border-brand-charcoal/10">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-12 gap-16 items-center">
        <div className="lg:col-span-5">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Showcase / In-Situ</span>
          <h2 className="text-6xl italic leading-tight mb-8">Craft in <br />Motion</h2>
          <p className="text-xl font-light text-brand-gray leading-relaxed mb-10">
            Static images are silent. They don't show the 1:1 scale planning or how we hide the chaos of modern technology behind clean Polish rzemiosło. Watch how a legacy home actually comes together.
          </p>
          <div className="flex gap-4">
            <div className="flex flex-col">
              <span className="text-xs font-bold uppercase tracking-widest opacity-40">Project</span>
              <span className="text-lg font-serif italic">Modern Library Transition</span>
            </div>
          </div>
        </div>
        <div className="lg:col-span-7">
          <div className="aspect-video bg-brand-charcoal shadow-2xl relative group overflow-hidden border border-brand-charcoal/10">
            <iframe 
              className="w-full h-full"
              src="https://www.youtube.com/embed/w6X1e2Ccqb4" 
              title="Trim Team NJ Project Showcase" 
              frameBorder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
              allowFullScreen
            ></iframe>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Awards = () => (
  <section id="awards" className="py-32 px-6 bg-white border-t border-brand-charcoal">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-12 gap-16 mb-24 items-end">
        <div className="lg:col-span-8">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Rankings & Recognition</span>
          <h2 className="text-7xl md:text-9xl italic leading-[0.85] mb-0 text-brand-charcoal">Standard of <br />Excellence</h2>
        </div>
        <div className="lg:col-span-4">
          <p className="text-xl font-light text-brand-gray leading-relaxed italic border-l border-brand-orange pl-8">
            "Recognized continuously since 2014. We don't compete for awards; we compete for the highest benchmark of service in New Jersey."
          </p>
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-16 items-start">
        <div className="space-y-12">
          <div>
            <h3 className="text-4xl uppercase mb-6 flex items-center gap-4">
              <Award className="text-brand-orange" size={32} />
              12 Consecutive Awards
            </h3>
            <p className="text-brand-gray leading-relaxed text-lg font-light mb-8">
              The 'Best of Houzz' is more than a badge. It is a merit-based system derived from over 65 million monthly users. Only the top 3% of professionals globally receive this distinction for service excellence and design innovation.
            </p>
            
            <div className="grid grid-cols-2 gap-8">
              <div className="border-t border-brand-charcoal pt-6">
                <span className="text-4xl font-serif italic text-brand-orange block mb-2">11×</span>
                <p className="text-[10px] uppercase tracking-widest font-bold opacity-60">Service Excellence</p>
                <p className="text-xs mt-2 text-brand-gray leading-relaxed">Voted by homeowners for consistent reliability and transparency.</p>
              </div>
              <div className="border-t border-brand-charcoal pt-6">
                <span className="text-4xl font-serif italic text-brand-orange block mb-2">1×</span>
                <p className="text-[10px] uppercase tracking-widest font-bold opacity-60">Design Merit 2026</p>
                <p className="text-xs mt-2 text-brand-gray leading-relaxed">Awarded for architectural relevance and structural beauty.</p>
              </div>
            </div>
          </div>

          <div className="p-8 bg-brand-cream border border-brand-charcoal/5 italic">
            <p className="text-brand-gray font-light leading-relaxed">
              "Verification is everything. Every award listed is linked to direct homeowner reviews from Union, Somerset, and Monmouth counties. When we say 5-star, we have the history to back it up."
            </p>
            <span className="block mt-4 text-[10px] uppercase tracking-widest font-bold text-brand-orange">— Sebastian Puc</span>
          </div>
        </div>

        <div className="bg-brand-charcoal p-12 text-white shadow-2xl">
          <div className="flex justify-between items-center mb-12">
            <span className="text-[10px] uppercase tracking-[0.4em] font-bold text-brand-orange">Timeline of Honor</span>
            <span className="text-xs opacity-40">Est. 2004</span>
          </div>
          
          <div className="flex flex-wrap gap-4">
            {[2014, 2015, 2016, 2017, 2018, 2019, 2022, 2023, 2024, 2025, 2026].map((year) => (
              <div key={year} className="flex flex-col items-center group cursor-default">
                <div className={`w-16 h-16 border ${year === 2026 ? 'border-brand-orange' : 'border-white/20'} flex flex-col items-center justify-center p-2 group-hover:border-brand-orange transition-colors`}>
                  <img 
                    src={`https://st.hzcdn.com/static/badge${year}_16.png`} 
                    alt={`Houzz ${year}`} 
                    className="w-8 h-8 object-contain mb-1"
                    onError={(e) => {
                      (e.target as HTMLImageElement).style.display = 'none';
                    }}
                  />
                  <span className={`text-[10px] font-bold ${year === 2026 ? 'text-brand-orange' : 'text-white/60'}`}>{year}</span>
                </div>
                <span className="text-[8px] uppercase tracking-tighter mt-1 opacity-40">Service</span>
              </div>
            ))}
          </div>
          
          <div className="mt-12 pt-8 border-t border-white/10 flex items-center gap-6">
            <div className="bg-brand-orange/20 p-4 rounded-full">
              <Award className="text-brand-orange" size={24} />
            </div>
            <div>
              <p className="text-sm font-bold uppercase tracking-widest">Houzz Design Award 2026</p>
              <p className="text-[10px] opacity-60 uppercase tracking-widest mt-1">First year entry — First year win</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Selectivity = () => {
  const [isMuted, setIsMuted] = useState(true);

  return (
    <section id="selectivity" className="py-32 px-6 bg-brand-charcoal text-white overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-12 gap-16 mb-24 items-center">
          <div className="lg:col-span-7">
            <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Honest Boundaries — Sebastian Puc</span>
            <h2 className="text-7xl md:text-9xl italic leading-[0.85] mb-10">When We <br />Are Not <br />For You</h2>
            <div className="p-8 bg-white/5 border-l-4 border-brand-orange italic text-2xl font-serif max-w-xl">
              "We want your project to be flawless. That means no surprises. We double-check every detail to protect your home. If we aren't a 100% match, I'll be the first to tell you."
            </div>
          </div>
          <div className="lg:col-span-5">
            <div className="aspect-[9/16] bg-brand-charcoal border-8 border-white/5 rounded-3xl overflow-hidden shadow-2xl relative group cursor-pointer" onClick={() => setIsMuted(!isMuted)}>
              <video 
                autoPlay 
                muted={isMuted}
                loop 
                playsInline 
                key={isMuted ? "muted" : "unmuted"}
                className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700"
              >
                <source src="https://storage.googleapis.com/antigravity-artifacts/input_file_0.mp4" type="video/mp4" />
                Your browser does not support the video tag.
              </video>
              <div className="absolute top-8 right-8 z-20 bg-brand-orange p-3 rounded-full shadow-lg">
                {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
              </div>
              <div className="absolute inset-x-0 bottom-0 p-8 bg-gradient-to-t from-black/80 to-transparent">
                <p className="text-xs uppercase tracking-widest font-bold text-brand-orange">Direct Message — Sebastian Puc</p>
                <p className="text-sm font-light italic">"Honesty is the foundation of every project. {isMuted ? 'Click to hear the truth.' : 'Listening...'}"</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-16">
        {[
          {
            title: "The Lowest Bidder",
            desc: "If you are gathering 5 quotes to find the cheapest number, we are not your team. Quality and speed require a margin that low-cost contractors cannot survive."
          },
          {
            title: "Quick Flips",
            desc: "We build for legacy and longevity. If you need it 'good enough to sell next month,' you are looking for a different level of craftsmanship."
          },
          {
            title: "DIY Coordination",
            desc: "The Home Refresh™ works because we manage the vetted specialists. If you want to hire your own plumber or painter and manage the schedule yourself, we cannot guarantee the outcome."
          },
          {
            title: "Outside our Radius",
            desc: "We serve Clark, NJ and a 70-minute radius. If you are in South Jersey or Upstate NY, the commute compromises our ability to be on-site and attentive every day."
          },
          {
            title: "Small Repairs",
            desc: "Our structural modeling and planning are designed for full modernizations. Projects under $5,000 do not utilize our team's specialized strengths effectively."
          },
          {
            title: "Commercial Properties",
            desc: "We are residential specialists. We know the layouts of 1995–2005 NJ homes by heart. We do not do retail, office, or restaurant build-outs."
          }
        ].map((item, i) => (
          <div key={i} className="flex flex-col border-t border-white/20 pt-8 group">
            <h4 className="text-2xl uppercase mb-4 text-brand-orange">{item.title}</h4>
            <p className="text-white/60 text-sm font-light leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>
      
      <div className="mt-24 p-12 bg-white/5 border border-white/10 text-center">
        <p className="text-3xl font-serif italic mb-0">Still reading? Then we likely speak the same language.</p>
      </div>
    </div>
  </section>
  );
};

const Process = () => (
  <section id="process" className="py-32 px-6 bg-white border-t border-brand-charcoal">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-12 gap-16 mb-24">
        <div className="lg:col-span-8">
          <span className="text-brand-orange uppercase text-[10px] tracking-[0.4em] font-bold block mb-6">Efficiency of Execution</span>
          <h2 className="text-7xl md:text-9xl italic leading-[0.85] mb-10">The Design <br />& Build Process</h2>
        </div>
        <div className="lg:col-span-4 lg:pt-20">
          <p className="text-xl font-light text-brand-gray leading-relaxed mb-8 italic">
            "We provide value before we ever ask for a commitment. Our process is designed to eliminate the friction and uncertainty usually associated with home improvement."
          </p>
          <div className="p-6 bg-brand-cream border-l-2 border-brand-orange">
            <p className="text-xs font-bold uppercase tracking-widest mb-2">Heritage Standard</p>
            <p className="text-sm font-light leading-relaxed">22 years of heritage ensures our timelines are accurate, not aspirational.</p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8 mb-32">
        {[
          {
            step: "01",
            title: "Inquiry & Ballpark",
            desc: "Let’s simplify. Send 3-5 photos of the space and basic dimensions. Sebastian provides a direction and a ballpark range within 24 hours (on business days). No sales pressure, just honest numbers based on 22 years of heritage."
          },
          {
            step: "02",
            title: "Design Agreement",
            desc: "A $300-$500 deposit initiates photorealistic 3D modeling showing the structure within your room's exact dimensions. We then meet at your home for a 1:1 scale layout using painter's tape on your walls to confirm proportions before fabrication."
          },
          {
            step: "03",
            title: "Off-Site Workshop",
            desc: "80% of our work happens in our shop. We fabricate shells from 3/4\" high-density MDF and decorative elements from FJ Wood. This ensures your home remains liveable and dust-free during the construction phase."
          },
          {
            step: "04",
            title: "Clean Installation",
            desc: "Our own crew works 8:00–16:00 sharp. We protect floors and furniture daily with professional-grade materials. Our benchmark is a 'zero-dust' daily cleanup, leaving your home cleaner than we found it every single day."
          },
          {
            step: "05",
            title: "Master Finishing",
            desc: "The final layer defines the legacy. We use Benjamin Moore Regal Select for a professional, durable finish. One team carries the responsibility for every mitered corner from first measure to the final coat."
          }
        ].map((item, i) => (
          <div key={i} className="flex flex-col border-t-2 border-brand-charcoal pt-8 group">
            <span className="text-4xl font-serif italic text-brand-orange mb-6">{item.step}</span>
            <h4 className="text-2xl uppercase mb-4 group-hover:text-brand-orange transition-colors leading-tight">{item.title}</h4>
            <p className="text-brand-gray text-sm font-light leading-relaxed">{item.desc}</p>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-12">
        <div className="p-12 bg-white border border-brand-charcoal shadow-[20px_20px_0px_0px_rgba(235,94,40,0.1)]">
          <div className="flex items-center gap-4 mb-8">
            <div className="bg-brand-orange p-3 text-white">
              <CheckCircle2 size={24} />
            </div>
            <h3 className="text-3xl uppercase font-bold">Home Refresh™ Note</h3>
          </div>
          <p className="text-brand-gray text-xl font-light leading-relaxed mb-10">
            For major modernizations, we employ our <span className="font-bold text-brand-charcoal">Concierge Model</span>. This means Trim Team acts as your single point of authority. We coordinate and manage every vetted specialist—plumbers, electricians, and tilers—so you have one cohesive outcome and one person to call.
          </p>
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <span className="text-brand-orange font-bold">01</span>
              <p className="text-sm">Unified responsibility for the entire project timeline.</p>
            </div>
            <div className="flex items-start gap-4 border-t border-brand-charcoal/10 pt-4">
              <span className="text-brand-orange font-bold">02</span>
              <p className="text-sm">Direct access to Sebastian for all structural and design decisions.</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col gap-8">
          <div className="flex-1 p-10 bg-brand-charcoal text-white">
            <h4 className="text-xs uppercase tracking-[0.3em] font-bold text-brand-orange mb-6">Material Integrity</h4>
            <h3 className="text-3xl italic font-serif mb-6">MDF & FJ Wood Specification</h3>
            <p className="text-white/70 font-light leading-relaxed mb-6">
              Modern NJ homes require stability. We use <span className="text-white font-bold">3/4" High-Density MDF</span> for structurally stable shells and <span className="text-white font-bold">Finger-Joint (FJ) Wood</span> for decorative trim. This combination prevents the warping and cracking common in lower-grade materials.
            </p>
          </div>
          
          <div className="flex-1 p-10 bg-brand-cream border border-brand-charcoal/10">
            <h4 className="text-xs uppercase tracking-[0.3em] font-bold text-brand-orange mb-6">Painting Benchmark</h4>
            <h3 className="text-3xl italic font-serif mb-6">Benjamin Moore Regal Select</h3>
            <p className="text-brand-gray font-light leading-relaxed mb-6">
              Our finishing process is not merely "painting." We utilize <span className="text-brand-charcoal font-bold">Benjamin Moore Regal Select</span>—the industry standard for durability and depth. Every project includes full preparation, sanding between coats, and a finish that is built to survive daily life.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const Contact = () => (
  <section id="contact" className="py-24 px-6 relative">
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-2 gap-20">
        <div>
          <h2 className="text-5xl md:text-7xl mb-8">Let's Talk.</h2>
          <p className="text-xl text-brand-gray font-light mb-12">
            A few photos. Rough dimensions. Your address. <br />
            That's enough to begin your 24-hour direction and ballpark pricing.
          </p>
          
          <div className="space-y-8">
            <a href="tel:9088649886" className="flex items-center gap-6 group">
              <div className="bg-brand-orange/10 p-4 rounded-full group-hover:bg-brand-orange group-hover:text-white transition-colors">
                <Phone size={24} />
              </div>
              <div>
                <span className="block text-[10px] uppercase tracking-widest font-bold opacity-50">Call directly</span>
                <span className="text-2xl font-serif">908 864 9886</span>
              </div>
            </a>
            <a href="mailto:hello@trimnj.com" className="flex items-center gap-6 group">
              <div className="bg-brand-orange/10 p-4 rounded-full group-hover:bg-brand-orange group-hover:text-white transition-colors">
                <Mail size={24} />
              </div>
              <div>
                <span className="block text-[10px] uppercase tracking-widest font-bold opacity-50">Email Fabian</span>
                <span className="text-2xl font-serif">hello@trimnj.com</span>
              </div>
            </a>
            <div className="flex items-center gap-6">
              <div className="bg-brand-orange/10 p-4 rounded-full">
                <MapPin size={24} />
              </div>
              <div>
                <span className="block text-[10px] uppercase tracking-widest font-bold opacity-50">Serving</span>
                <span className="text-2xl font-serif">Clark, NJ & 70 min radius</span>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white p-10 shadow-2xl shadow-brand-charcoal/5 border border-brand-charcoal/5">
          <form className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest font-bold">Full Name</label>
                <input type="text" className="w-full bg-brand-cream/30 border border-brand-charcoal/10 p-4 focus:outline-none focus:border-brand-orange" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] uppercase tracking-widest font-bold">Town in NJ</label>
                <input type="text" className="w-full bg-brand-cream/30 border border-brand-charcoal/10 p-4 focus:outline-none focus:border-brand-orange" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold">Email Address</label>
              <input type="email" className="w-full bg-brand-cream/30 border border-brand-charcoal/10 p-4 focus:outline-none focus:border-brand-orange" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold">Project Interest</label>
              <select className="w-full bg-brand-cream/30 border border-brand-charcoal/10 p-4 focus:outline-none focus:border-brand-orange">
                <option>Home Refresh™ (Full scope)</option>
                <option>Custom Woodwork / Built-ins</option>
                <option>Interior Painting (Stain/Paint-grade)</option>
                <option>Small Project ($5k+)</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] uppercase tracking-widest font-bold">Tell us about your home</label>
              <textarea rows={4} className="w-full bg-brand-cream/30 border border-brand-charcoal/10 p-4 focus:outline-none focus:border-brand-orange" placeholder="Age of home, room type, your vision..."></textarea>
            </div>
            <button className="w-full bg-brand-charcoal text-white py-6 text-xs uppercase tracking-[0.3em] font-bold hover:bg-brand-orange transition-colors">
              Submit Inquiry
            </button>
          </form>
        </div>
      </div>
    </div>
  </section>
);

const Chatbot = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<{ role: 'user' | 'model'; text: string }[]>([
    { role: 'model', text: "I am Sebastian. You have questions about your home? Ask them. I don't have time for fluff, so be direct." }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: [...messages, { role: 'user', text: userMessage }].map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        })),
        config: {
          systemInstruction: `You are Sebastian Puc, founder of Trim Team NJ. Your voice is the 'Trusted Elder'. Direct. Authoritative. Honest.
Your philosophy: 'Good work is fast work. Mistakes from haste cost more than the time saved.'

Voice Guidelines:
- BE CONCISE. Use short, punchy sentences. No fluff.
- Use woodworking analogies (mitered corners, rzemiosło, grain direction, structural honesty).
- Do not apologize. Speak from 22 years of heritage.
- If someone asks about price: 'Cheap work is expensive in the long run. If you want it done right once, I am here. Otherwise, do not call.'

Context:
- Project Showcase: Modern Library (1:1 scale planning).
- Materials: 3/4" MDF for shells, FJ Wood for trim.
- Finish: Benjamin Moore Regal Select.
- Selectivity: No quick flips, no lowest bidders, no DIY managers.

Responses should feel like a master craftsman talking to a client on-site. Brief. To the point.`
        }
      });

      const modelResponse = response.text || "That's a structural failure in the message. Ask again.";
      setMessages(prev => [...prev, { role: 'model', text: modelResponse }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Service is down. Call my line if it's urgent: 908 864 9886." }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-8 right-8 z-[100] flex flex-col items-end">
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          className="w-80 md:w-96 h-[500px] bg-white shadow-2xl border border-brand-charcoal flex flex-col mb-4 overflow-hidden"
        >
          <div className="bg-brand-charcoal p-4 text-white flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-brand-orange flex items-center justify-center font-serif italic text-sm">SP</div>
              <div>
                <p className="text-sm font-bold uppercase tracking-widest leading-none">Sebastian Puc</p>
                <p className="text-[10px] opacity-60 uppercase font-bold tracking-widest mt-1">Founding Authority</p>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:text-brand-orange transition-colors">
              <X size={20} />
            </button>
          </div>

          <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-brand-cream/30">
            {messages.map((m, i) => (
              <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[80%] p-3 text-sm ${
                  m.role === 'user' 
                    ? 'bg-brand-orange text-white rounded-l-lg rounded-tr-lg' 
                    : 'bg-white border border-brand-charcoal/10 text-brand-charcoal rounded-r-lg rounded-tl-lg shadow-sm font-light'
                }`}>
                  {m.text}
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white border border-brand-charcoal/10 p-3 rounded-r-lg rounded-tl-lg flex items-center gap-2">
                  <Loader2 size={16} className="animate-spin text-brand-orange" />
                  <span className="text-[10px] uppercase font-bold tracking-widest opacity-40">Sebastian is thinking...</span>
                </div>
              </div>
            )}
          </div>

          <div className="p-4 border-t border-brand-charcoal/5 bg-white">
            <div className="flex gap-2">
              <input 
                type="text" 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Ask about your project..."
                className="flex-1 bg-brand-cream/50 border-none px-4 py-2 text-sm font-light focus:ring-1 focus:ring-brand-orange outline-none"
              />
              <button 
                onClick={handleSend}
                disabled={isLoading}
                className="bg-brand-charcoal text-white p-2 hover:bg-brand-orange transition-colors disabled:opacity-50"
              >
                <Send size={18} />
              </button>
            </div>
          </div>
        </motion.div>
      )}

      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-16 h-16 bg-brand-charcoal text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform group relative"
      >
        {isOpen ? <X size={28} /> : <MessageCircle size={28} />}
        {!isOpen && (
          <div className="absolute -top-12 right-0 bg-brand-orange text-white text-[10px] font-bold py-2 px-4 rounded-full whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
            Talk to Sebastian
          </div>
        )}
      </button>
    </div>
  );
};

const Footer = () => (
  <footer className="bg-brand-charcoal text-white/50 py-20 px-6">
    <div className="max-w-7xl mx-auto">
      <div className="grid md:grid-cols-4 gap-12 mb-20">
        <div className="col-span-2">
          <div className="flex flex-col mb-8">
            <span className="text-2xl font-bold text-white uppercase tracking-tight">Trim Team NJ</span>
            <span className="text-[10px] uppercase tracking-[0.2em] font-medium opacity-60">Design & Build</span>
          </div>
          <p className="max-w-sm mb-8 leading-relaxed">
            A family-owned firm specializing in NJ residential updates. 22 years of heritage, Polish tradition, and zero shortcuts.
          </p>
          <div className="flex gap-4">
            <Award className="text-brand-orange opacity-100" />
            <span className="text-[11px] uppercase tracking-widest font-bold text-white/80">NJ License: #13VH04919500</span>
          </div>
        </div>
        
        <div>
          <h5 className="text-white text-[10px] uppercase tracking-[0.3em] font-bold mb-6">Service Areas</h5>
          <ul className="text-sm space-y-3">
            <li>Monmouth County</li>
            <li>Morris County</li>
            <li>Somerset County</li>
            <li>Union & Essex</li>
            <li>Single-Family Homes Only</li>
          </ul>
        </div>

        <div>
          <h5 className="text-white text-[10px] uppercase tracking-[0.3em] font-bold mb-6">Contact</h5>
          <ul className="text-sm space-y-3">
            <li>Clark, NJ 07066</li>
            <li>908 864 9886</li>
            <li>hello@trimnj.com</li>
          </ul>
        </div>
      </div>

      <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
        <p className="text-[10px] uppercase tracking-widest">© 2026 Trim Team NJ. All rights reserved.</p>
        <div className="flex gap-8 text-[10px] uppercase tracking-widest font-bold text-white/30">
          <a href="#" className="hover:text-white transition-colors underline-offset-4 underline">Privacy Policy</a>
          <a href="#" className="hover:text-white transition-colors underline-offset-4 underline">Terms of Service</a>
        </div>
      </div>
    </div>
  </footer>
);

export default function App() {
  return (
    <div className="min-h-screen bg-brand-cream selection:bg-brand-orange selection:text-white">
      <Navbar />
      <main>
        <Hero />
        <BrandVoice />
        <HomeRefresh />
        <ClientStories />
        <ProjectShowcase />
        <Gallery />
        <CoreServices />
        <Philosophy />
        <Awards />
        <Selectivity />
        <Process />
        <Testimonials />
        <MeetTheCrew />
        <Contact />
      </main>
      <Chatbot />
      <Footer />
    </div>
  );
}
